/**
 * Created by riblee on 4/11/16.
 */
import { Component } from 'angular2/core';

@Component({
    selector: 'home-component',
    templateUrl: 'app/home/home.html'
})

export class HomeComponent { }