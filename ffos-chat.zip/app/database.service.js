System.register(['rxjs/Observable', 'rxjs/Subject', '@angular/core', 'rxjs/add/operator/mergeMap', 'rxjs/add/operator/map', 'rxjs/add/operator/do', 'rxjs/add/operator/toArray', 'rxjs/add/observable/from'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = (this && this.__param) || function (paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    };
    var Observable_1, Subject_1, core_1;
    var IDB_SUCCESS, IDB_COMPLETE, IDB_ERROR, IDB_UPGRADE_NEEDED, IDB_TXN_READ, IDB_TXN_READWRITE, DB_INSERT, DatabaseBackend, IDB_SCHEMA, getIDBFactory, Database, DB_PROVIDERS, provideDB;
    return {
        setters:[
            function (Observable_1_1) {
                Observable_1 = Observable_1_1;
            },
            function (Subject_1_1) {
                Subject_1 = Subject_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (_1) {},
            function (_2) {},
            function (_3) {},
            function (_4) {},
            function (_5) {}],
        execute: function() {
            IDB_SUCCESS = 'success';
            IDB_COMPLETE = 'complete';
            IDB_ERROR = 'error';
            IDB_UPGRADE_NEEDED = 'upgradeneeded';
            IDB_TXN_READ = 'readonly';
            IDB_TXN_READWRITE = 'readwrite';
            exports_1("DB_INSERT", DB_INSERT = 'DB_INSERT');
            exports_1("DatabaseBackend", DatabaseBackend = new core_1.OpaqueToken('IndexedDBBackend'));
            exports_1("IDB_SCHEMA", IDB_SCHEMA = new core_1.OpaqueToken('IDB_SCHEMA'));
            exports_1("getIDBFactory", getIDBFactory = function () { return window.indexedDB || self.indexedDB; });
            Database = (function () {
                function Database(idbBackend, schema) {
                    this.changes = new Subject_1.Subject();
                    this._schema = schema;
                    this._idb = idbBackend;
                }
                Database.prototype._mapRecord = function (objectSchema) {
                    return function (dbResponseRec) {
                        if (!objectSchema.primaryKey) {
                            dbResponseRec.record['$key'] = dbResponseRec['$key'];
                        }
                        return dbResponseRec.record;
                    };
                };
                Database.prototype._upgradeDB = function (observer, db) {
                    for (var storeName in this._schema.stores) {
                        if (db.objectStoreNames.contains(storeName)) {
                            db.deleteObjectStore(storeName);
                        }
                        this._createObjectStore(db, storeName, this._schema.stores[storeName]);
                    }
                    observer.next(db);
                    observer.complete();
                };
                Database.prototype._createObjectStore = function (db, key, schema) {
                    var objectStore = db.createObjectStore(key, { autoIncrement: true, keyPath: schema.primaryKey });
                };
                Database.prototype.open = function (dbName, version, upgradeHandler) {
                    var _this = this;
                    if (version === void 0) { version = 1; }
                    var idb = this._idb;
                    return Observable_1.Observable.create(function (observer) {
                        var openReq = idb.open(dbName, _this._schema.version);
                        var onSuccess = function (event) {
                            observer.next(event.target.result);
                            observer.complete();
                        };
                        var onError = function (err) {
                            console.log(err);
                            observer.error(err);
                        };
                        var onUpgradeNeeded = function (event) {
                            _this._upgradeDB(observer, event.target.result);
                        };
                        openReq.addEventListener(IDB_SUCCESS, onSuccess);
                        openReq.addEventListener(IDB_ERROR, onError);
                        openReq.addEventListener(IDB_UPGRADE_NEEDED, onUpgradeNeeded);
                        return function () {
                            openReq.removeEventListener(IDB_SUCCESS, onSuccess);
                            openReq.removeEventListener(IDB_ERROR, onError);
                            openReq.removeEventListener(IDB_UPGRADE_NEEDED, onUpgradeNeeded);
                        };
                    });
                };
                Database.prototype.deleteDatabase = function (dbName) {
                    var _this = this;
                    return new Observable_1.Observable(function (deletionObserver) {
                        var deleteRequest = _this._idb.deleteDatabase(dbName);
                        var onSuccess = function (event) {
                            deletionObserver.next(null);
                            deletionObserver.complete();
                        };
                        var onError = function (err) { return deletionObserver.error(err); };
                        deleteRequest.addEventListener(IDB_SUCCESS, onSuccess);
                        deleteRequest.addEventListener(IDB_ERROR, onError);
                        return function () {
                            deleteRequest.removeEventListener(IDB_SUCCESS, onSuccess);
                            deleteRequest.removeEventListener(IDB_ERROR, onError);
                        };
                    });
                };
                Database.prototype.insert = function (storeName, records, notify) {
                    var _this = this;
                    if (notify === void 0) { notify = true; }
                    return this.executeWrite(storeName, 'put', records)
                        .do(function (payload) { return notify ? _this.changes.next({ type: DB_INSERT, payload: payload }) : ({}); });
                };
                Database.prototype.get = function (storeName, key) {
                    var _this = this;
                    return this.open(this._schema.name)
                        .mergeMap(function (db) {
                        return new Observable_1.Observable(function (txnObserver) {
                            var recordSchema = _this._schema.stores[storeName];
                            var mapper = _this._mapRecord(recordSchema);
                            var txn = db.transaction([storeName], IDB_TXN_READ);
                            var objectStore = txn.objectStore(storeName);
                            var getRequest = objectStore.get(key);
                            var onTxnError = function (err) { return txnObserver.error(err); };
                            var onTxnComplete = function () { return txnObserver.complete(); };
                            var onRecordFound = function (ev) { return txnObserver.next(getRequest.result); };
                            txn.addEventListener(IDB_COMPLETE, onTxnComplete);
                            txn.addEventListener(IDB_ERROR, onTxnError);
                            getRequest.addEventListener(IDB_SUCCESS, onRecordFound);
                            getRequest.addEventListener(IDB_ERROR, onTxnError);
                            return function () {
                                getRequest.removeEventListener(IDB_SUCCESS, onRecordFound);
                                getRequest.removeEventListener(IDB_ERROR, onTxnError);
                                txn.removeEventListener(IDB_COMPLETE, onTxnComplete);
                                txn.removeEventListener(IDB_ERROR, onTxnError);
                            };
                        });
                    });
                };
                Database.prototype.query = function (storeName, predicate) {
                    return this.open(this._schema.name)
                        .mergeMap(function (db) {
                        return new Observable_1.Observable(function (txnObserver) {
                            var txn = db.transaction([storeName], IDB_TXN_READ);
                            var objectStore = txn.objectStore(storeName);
                            var getRequest = objectStore.openCursor();
                            var onTxnError = function (err) { return txnObserver.error(err); };
                            var onRecordFound = function (ev) {
                                var cursor = ev.target.result;
                                if (cursor) {
                                    if (predicate) {
                                        var match = predicate(cursor.value);
                                        if (match) {
                                            txnObserver.next(cursor.value);
                                        }
                                    }
                                    else {
                                        txnObserver.next(cursor.value);
                                    }
                                    cursor.continue();
                                }
                                else {
                                    txnObserver.complete();
                                }
                            };
                            txn.addEventListener(IDB_ERROR, onTxnError);
                            getRequest.addEventListener(IDB_SUCCESS, onRecordFound);
                            getRequest.addEventListener(IDB_ERROR, onTxnError);
                            return function () {
                                getRequest.removeEventListener(IDB_SUCCESS, onRecordFound);
                                getRequest.removeEventListener(IDB_ERROR, onTxnError);
                                txn.removeEventListener(IDB_ERROR, onTxnError);
                            };
                        });
                    });
                };
                Database.prototype.executeWrite = function (storeName, actionType, records) {
                    var _this = this;
                    var changes = this.changes;
                    return this.open(this._schema.name)
                        .mergeMap(function (db) {
                        return new Observable_1.Observable(function (txnObserver) {
                            var recordSchema = _this._schema.stores[storeName];
                            var mapper = _this._mapRecord(recordSchema);
                            var txn = db.transaction([storeName], IDB_TXN_READWRITE);
                            var objectStore = txn.objectStore(storeName);
                            var onTxnError = function (err) { return txnObserver.error(err); };
                            var onTxnComplete = function () { return txnObserver.complete(); };
                            txn.addEventListener(IDB_COMPLETE, onTxnComplete);
                            txn.addEventListener(IDB_ERROR, onTxnError);
                            var makeRequest = function (record) {
                                return new Observable_1.Observable(function (reqObserver) {
                                    var req;
                                    if (recordSchema.primaryKey) {
                                        req = objectStore[actionType](record);
                                    }
                                    else {
                                        var $key = record['$key'];
                                        var $record = Object.assign({}, record);
                                        delete $record.key;
                                        req = objectStore[actionType]($record, $key);
                                    }
                                    req.addEventListener(IDB_SUCCESS, function () {
                                        var $key = req.result;
                                        reqObserver.next(mapper({ $key: $key, record: record }));
                                    });
                                    req.addEventListener(IDB_ERROR, function (err) {
                                        reqObserver.error(err);
                                    });
                                });
                            };
                            var requestSubscriber = Observable_1.Observable.from(records)
                                .mergeMap(makeRequest)
                                .subscribe(txnObserver);
                            return function () {
                                requestSubscriber.unsubscribe();
                                txn.removeEventListener(IDB_COMPLETE, onTxnComplete);
                                txn.removeEventListener(IDB_ERROR, onTxnError);
                            };
                        });
                    });
                };
                Database.prototype.compare = function (a, b) {
                    return this._idb.cmp(a, b);
                };
                Database = __decorate([
                    __param(0, core_1.Inject(DatabaseBackend)),
                    __param(1, core_1.Inject(IDB_SCHEMA)), 
                    __metadata('design:paramtypes', [Object, Object])
                ], Database);
                return Database;
            }());
            exports_1("Database", Database);
            exports_1("DB_PROVIDERS", DB_PROVIDERS = [
                core_1.provide(DatabaseBackend, { useFactory: getIDBFactory }),
                Database
            ]);
            exports_1("provideDB", provideDB = function (schema) {
                return DB_PROVIDERS.concat([core_1.provide(IDB_SCHEMA, { useValue: schema })]);
            });
        }
    }
});
//# sourceMappingURL=database.service.js.map